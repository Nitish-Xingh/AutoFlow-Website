(() => {
  const menuButton = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  if (menuButton && nav) {
    menuButton.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      menuButton.setAttribute('aria-expanded', String(isOpen));
      menuButton.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('open');
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.setAttribute('aria-label', 'Open navigation');
    }));
  }

  // A failed or unusually slow stock image is replaced by a bundled local illustration.
  // This avoids broken-image icons and empty image panels on weak connections.
  document.querySelectorAll('img[data-fallback]').forEach(img => {
    const useFallback = () => {
      const fallback = img.dataset.fallback;
      if (fallback && !img.dataset.fallbackUsed && img.naturalWidth === 0) {
        img.dataset.fallbackUsed = 'true';
        img.src = fallback;
      }
    };
    img.addEventListener('error', useFallback, { once: true });
    if (img.complete && img.naturalWidth === 0) useFallback();
    const startSlowLoadCheck = () => window.setTimeout(() => {
      if (!img.complete || img.naturalWidth === 0) useFallback();
    }, 8000);
    if (img.loading === 'lazy' && 'IntersectionObserver' in window) {
      const imageObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            imageObserver.unobserve(img);
            startSlowLoadCheck();
          }
        });
      }, { rootMargin: '350px' });
      imageObserver.observe(img);
    } else {
      startSlowLoadCheck();
    }
  });

  const revealItems = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -35px 0px' });
    revealItems.forEach(item => observer.observe(item));
  } else {
    revealItems.forEach(item => item.classList.add('visible'));
  }

  const year = document.getElementById('year');
  if (year) year.textContent = String(new Date().getFullYear());

  const form = document.getElementById('contact-form');
  const note = document.getElementById('form-note');
  if (form) {
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const data = new FormData(form);
      const name = String(data.get('name') || '').trim();
      const business = String(data.get('business') || '').trim();
      const task = String(data.get('task') || '').trim();
      const message = String(data.get('message') || '').trim();
      const lines = [
        'Hi Autoflow Services, I would like to discuss a business workflow.',
        '', `Name: ${name}`,
        business ? `Business: ${business}` : null,
        `Area of help: ${task}`,
        message ? `A little more detail: ${message}` : null
      ].filter(Boolean);
      const url = `https://wa.me/916900513214?text=${encodeURIComponent(lines.join('\n'))}`;
      const opened = window.open(url, '_blank');
      if (opened) opened.opener = null;
      if (!opened) {
        if (note) {
          note.textContent = 'Your browser blocked the WhatsApp window. Use the WhatsApp button at the bottom or call +91 69005 13214.';
          note.classList.add('error');
        }
      } else if (note) {
        note.textContent = 'WhatsApp is opening with your message ready. Review it and press Send there.';
        note.classList.remove('error');
      }
    });
  }
})();
