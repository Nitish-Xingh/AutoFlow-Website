# Autoflow Services — website

A responsive, static website for Autoflow Services. It uses plain HTML, CSS and JavaScript: no framework, build step, API key, database or paid dependency is required.

## Preview locally

Open `index.html` in a browser, or run a local server from this folder:

```bash
python -m http.server 8080
```

Then visit `http://localhost:8080`.

## Deploy to Vercel

1. Create a GitHub repository and upload the contents of this folder (keep `index.html`, `styles.css`, `script.js`, `vercel.json` and the `assets` folder together).
2. In Vercel, choose **Add New → Project** and import that repository.
3. Choose **Other** as the framework preset. Leave Build Command and Output Directory empty/default; the site is served directly from the project root.
4. Deploy.

You can also use the Vercel CLI from this folder:

```bash
npx vercel
```

For production deployment:

```bash
npx vercel --prod
```

## Important details

- Contact form: opens WhatsApp with the visitor's details pre-filled. It does not store or submit the information to a server.
- WhatsApp / phone: `+91 69005 13214`.
- Email: `nitishxingh25@gmail.com`.
- Address: NS Rd, Sarabbhati, Sankarpur, Birubari, Guwahati, Assam 781016, India.
- The logo is the one supplied for Autoflow Services.
- Editorial photos load from Unsplash. Each photo has a bundled local PNG fallback, so a missing/blocked image does not leave a broken-image icon or blank image box. The main illustrations and logo are stored locally.

## Before launch

1. Confirm the address spelling and contact number are still correct.
2. Add a real business domain in Vercel when available.
3. Add Instagram / Facebook links only once you have the exact profile URLs. They were not included because the supplied profile screenshot did not show working URLs.
4. If you want the contact form to save leads in a CRM or spreadsheet, connect a backend or automation endpoint; the current version deliberately opens WhatsApp only.
